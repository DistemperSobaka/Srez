﻿using Srez.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Srez.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
   
    public partial class OrderPage : Page
    {
        public Order CurretOrder;
        List<Order> Orders = new List<Order>();
        public OrderPage()
        {
            InitializeComponent();
            AllOrderView.ItemsSource = BD.entities.Order.ToList();
        }

        private void EditButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (CurretOrder != null)
            {
                NavigationService.Navigate(new EditPage(CurretOrder));
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            AllOrderView.ItemsSource = BD.entities.Order.Where(c => c.OredrItem.Contains(SearchBox.Text)).ToList();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurretOrder != null && MessageBox.Show("Вы действительно хотите удалить выбранный объект?", "Сообщение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {

                Order order = AllOrderView.SelectedItem as Order;
                BD.entities.Order.Remove(order);
                BD.entities.SaveChanges();
                AllOrderView.ItemsSource = BD.entities.Order.ToList();

            }
            else
            {
                MessageBox.Show("Выберите объект для удаления", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditPage());
        }

        private void AllOrderView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CurretOrder = (Order)AllOrderView.SelectedItem;
        }
    }
}
